#ifndef	__FLASH_H__
#define __FLASH_H__

#include "define_all.h"  

extern void FlashInit(void);
extern uint8_t Flash_Erase_Sector( uint16_t SectorNum);
extern uint8_t Flash_Write_String( uint32 prog_addr,uint32_t* prog_data, uint16_t Len);

#endif
