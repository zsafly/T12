#ifndef	__MAIN_H__
#define __MAIN_H__

#include "define_all.h"  


extern uint08	BootEnable;
extern uint16	JumpCount;
extern uint32	FlashOpID;

#endif
