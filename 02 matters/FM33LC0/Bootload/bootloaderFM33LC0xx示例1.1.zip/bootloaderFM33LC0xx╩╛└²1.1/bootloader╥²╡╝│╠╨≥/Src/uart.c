#include "main.h" 

struct COMMUNICATION_FRM Uart[4];
extern uint08	BootEnable;
uint32	write_buf[128];
unsigned char  Cal_ChkSum(unsigned char *Buf,unsigned char Len)
{
	unsigned char i,csdata=0;
	
	for(i=0;i<Len;i++)
	{
		csdata+= Buf[i];
	}
	return(csdata);
}

//3. CRC16-CCITT
void Init_CRC_CRC16CCITT(void)
{
    LL_CRC_InitTypeDef CRC_InitStruct;
    
    CRC_InitStruct.CalculatMode = LL_CRC_CALCULA_MODE_SERIAL;
    CRC_InitStruct.DataWidth = LL_CRC_CRC_DR_WIDTH_BYTE;
    CRC_InitStruct.InitVel = 0x0000;
    CRC_InitStruct.Polynomial = 0x1021;
    CRC_InitStruct.PolynomialWidth = LL_CRC_POLYNOMIAL_WIDTH_16BIT;
    CRC_InitStruct.ReflectIn = LL_CRC_INPUT_REFLECTE_MODE_BYTE;
    CRC_InitStruct.ReflectOut = LL_CRC_OUPUT_REFLECTE_MODE_REVERSE;
    CRC_InitStruct.XorReg = 0x0000;
    CRC_InitStruct.XorRegState = DISABLE;
    LL_CRC_Init(CRC, &CRC_InitStruct);
}


//CRC-16/CCITT x16+x12+x5+1 0x1021
//Init = 0x0000
//RefIn��RefOut
//�������ߵ��ֽڵ������
unsigned int CalCRC16_CCITT( uint16 Init, uint08 *DataIn, uint16 Len )
{
	uint16 i, CRC16;

	LL_CRC_SetLinearShiftReg(CRC,Init);	//��ֵ�Ĵ���
	
	for( i=0; i<Len; i++ )
	{
		LL_CRC_SetDataReg(CRC,DataIn[i]);//��������Ĵ���
		Do_DelayStart();
		{
			if(RESET == LL_CRC_IsActiveFlag_Busy(CRC))
			{
				break;
			}
		}While_DelayUsEnd(200);
	}

	CRC16 = LL_CRC_GetDataReg(CRC) & 0xffff;
	return CRC16;
}

unsigned int BitChange(unsigned int us_DataIn)
{
unsigned int us_Data = us_DataIn;
us_Data = ((us_Data & 0xFF00) >> 8) | ((us_Data & 0x00FF) << 8);
us_Data = ((us_Data & 0xF0F0) >> 4) | ((us_Data & 0x0F0F) << 4);
us_Data = ((us_Data & 0xCCCC) >> 2) | ((us_Data & 0x3333) << 2);
us_Data = ((us_Data & 0xAAAA) >> 1) | ((us_Data & 0x5555) << 1);

return (us_Data);
}

FlagStatus Uart_RxErr_ChkEx(UART_Type* UARTx)
{
	if( (SET == LL_UART_IsActiveFlag_PERR(UARTx))
	||(SET == LL_UART_IsActiveFlag_FERR(UARTx))
	||(SET == LL_UART_IsActiveFlag_RXERR(UARTx)) )
	{
		return SET;
	}
	else
	{
		return RESET;
	}	
}

void Uart_RxErr_ClrEx(UART_Type* UARTx)
{
	LL_UART_ClearFlag_PERR(UARTx);
	LL_UART_ClearFlag_FERR(UARTx);
	LL_UART_ClearFlag_RXERR(UARTx);	
}


uint08 Uart_RXErr_Proc( uint08 Ch )
{
	uint08 status = 0;
	
	if( Ch == CHHW ) 
	{		
		if( SET == Uart_RxErr_ChkEx(UART4))
		{
			status = 0xaa;
			Uart_RxErr_ClrEx(UART4);		
		}
	}
	if( Ch == CH485 ) 
	{	
		if( SET == Uart_RxErr_ChkEx(UART1))
		{
			status = 0xaa;
			Uart_RxErr_ClrEx(UART1);
		}
	}
	if( Ch == CHZB ) 
	{	
		if( SET == Uart_RxErr_ChkEx(UART0))
		{
			status = 0xaa;
			Uart_RxErr_ClrEx(UART0);
		}
	}

	return status;
}

uint08 Judge_RX_Frame( uint08 Ch, uint08 RcvData ) ////���մ���
{
	unsigned char status=0;
	
	Uart[Ch].Overtime_Timer = txtimeout_max;//���ճ�ʱ
			
	switch( Uart[Ch].Step )
	{
		case 0x00: //�ȴ�����0x68
			if( RcvData == 0x68 )
			{
				Uart[Ch].Flag &= B1111_0000; //ͨѶ��־����
				Uart[Ch].Step = 0x01;
				Uart[Ch].Len = 0;
			}
			else
			{
				status = 0xaa;	//��ʾ���մ���
			}
			break;
			
		case 0x01: //�ȴ�����2�ֽ����ݳ���
			if ( (Uart[Ch].Len) >= 2 )
			{
				Uart[Ch].Total_Len = Uart[Ch].Buf[1]*256+RcvData;//ֻ�ϵڶ����ֽڣ����ֽڲ�����
				Uart[Ch].Step = 0x02; //�ȴ����յڶ���0x68
			}
			break;
	
		case 0x02: //�ȴ����յڶ���0x68
			if( RcvData == 0x68 )
			{
				Uart[Ch].Flag = 0x00;//ͨѶ��־����
				Uart[Ch].Step = 0x05; //�ȴ�����DATA
			}
			else
			{
				status = 0xaa;	//��ʾ���մ���		
			}
			break;
	
		case 0x05: //�ȴ�����DATA
			if( Uart[Ch].Len == ( Uart[Ch].Total_Len + 3) ) //���ݽ�����ȫ
			{
				Uart[Ch].Step = 0x06; //�ȴ�����cs.								
			}
			
			if( Uart[Ch].Len > ( Uart[Ch].Total_Len + 3) ) //֡���������
			{
				status = 0xaa; //��ʾ���մ���									
			}
			break;
	
		case 0x06: //�ȴ�����cs.
			if( Uart[Ch].Len == ( Uart[Ch].Total_Len + 5) ) //CRCУ�������ȫ
			{
				Uart[Ch].Step = 0x07; //�ȴ�����0x16			
			}
			if( Uart[Ch].Len > ( Uart[Ch].Total_Len + 5) ) //У�����
			{
				status = 0xaa; //��ʾ���մ���									
			}		
			break;
			
		case 0x07: //�ȴ�����0x16
			if( RcvData == 0x16 )
			{
				Uart[Ch].Step = 0x08;//�ֽڽ�����ȷ
				Uart[Ch].Overtime_Timer = 0x00;//����ճ�ʱ
				Uart[Ch].Response_Timer = framedelay_mx;//����Ӧ��ʱ
				Uart[Ch].Flag |= B0000_0100;//����֡���ݽ�����ɱ�־
			}
			else
			{
				status = 0xaa;	//��ʾ���մ���
			}
			break;

		default:
			status = 0xaa;	//��ʾ���մ���
			break;
	}
	
	if( status == 0x00 )	//�ֽڽ�����ȷ
	{
		Uart[Ch].Buf[Uart[Ch].Len] = RcvData;
		Uart[Ch].Len++;
	}
	
	if (Uart_RXErr_Proc( Ch ))
	{
		status = 0xaa;
	}
		
	if( status == 0xaa )	//���մ���
	{
		Uart[Ch].Step = 0x00;
		Uart[Ch].Flag &= B1111_1100;//���645�е���λ��㲥��ַ
	}
	
	return Uart[Ch].Step;
}


void Tx_Frame( uint08 Ch )	//using 1	//���ݷ���
{
	uint08 Temp08;
	
	if( Uart[Ch].Len >= Uart[Ch].Total_Len )
	{
		Uart[Ch].Overtime_Timer = 2;//ͨ����ʱ���Ƹ�λͨѶ
	}
	else
	{
		Temp08 = Uart[Ch].Buf[Uart[Ch].Len];		
		if( Ch == CHHW ) 
		{	
			LL_UART_TransmitData(UART4, Temp08);
		}
		else if( Ch == CH485 ) 
		{	
			LL_UART_TransmitData(UART1, Temp08);
		}
		else if( Ch == CHZB ) 
		{	
			LL_UART_TransmitData(UART0, Temp08);
		}
	
		Uart[Ch].Len++;

		Uart[Ch].Overtime_Timer = txtimeout_max;//���ͳ�ʱ
	}
}


void Exchange(unsigned char *BufA, unsigned char *BufB, unsigned char Len )
{
	unsigned char n;
	for( n=0; n<Len; n++ )
	{
		BufA[n] = BufB[Len-1-n];//��������
	}
}


void Uart_Proc(unsigned char Ch)
{
	uint16 i;
	uint16 crc16;
	uint08 command[2];
	uint08 result;
	uint16 Temp16;
	uint16 TxDataLen;
	uint32 Temp32;
	uint32 check_len;	
	uint32 Temp32_len;	
	uint08 RamBuf[512];
//	unsigned int j;
	
	Uart[Ch].Flag &= ~(B0000_0100);	
	
	Temp16 = Uart[Ch].Buf[1]*256 + Uart[Ch].Buf[2] + 4;
	crc16 = CalCRC16_CCITT(0x0000, Uart[Ch].Buf, Temp16);	
	
	if( Uart[Ch].Buf[Temp16]*256 + Uart[Ch].Buf[Temp16+1] != crc16 )
	{	
		return;
	}	
	//�����
	command[0] = Uart[Ch].Buf[4];
	command[1] = Uart[Ch].Buf[5];
	Temp32 = (Uart[Ch].Buf[6]<<24) | (Uart[Ch].Buf[7]<<16) | (Uart[Ch].Buf[8]<<8) | (Uart[Ch].Buf[9]);

	
	TxDataLen = 0;
	switch(command[0])
	{
		case 0x15:
			switch(command[1])
			{
				//flash erase all
				case 0x01:

					for(i=0;i<(PROGRAMEND1 + 1 - APPLICATION_ADDRESS)/512;i++)
					{
						IWDT_Clr();
						Flash_Erase_Sector( APPLICATION_ADDRESS/512+i);
					}
				break;
				
				//flash erase sector
				case 0x02:
					Flash_Erase_Sector( Temp32/512);
				break;

				//flash read sector
				case 0x04:
					TxDataLen = 512;
					memcpy( Uart[Ch].Buf+10, (unsigned char *)Temp32, 512 );
				break;
				
				////flash write sector
				case 0x08:
                    memcpy( write_buf ,Uart[Ch].Buf+10, 512);
					result = Flash_Write_String( Temp32, write_buf, 512/4);
					if(result)	Uart[Ch].Buf[4] |= 0x40;
				break;
				
				case 0xFD://���CRC
					memset(RamBuf, 0x00, 512);
					TxDataLen = 6;
					check_len = (Uart[Ch].Buf[10]<<24) | (Uart[Ch].Buf[11]<<16) | (Uart[Ch].Buf[12]<<8) | (Uart[Ch].Buf[13]);
					crc16 = 0x0000;
					for(Temp32_len = 0; Temp32_len<check_len; Temp32_len += 512)
					{
						crc16 = BitChange(crc16);
						memcpy( RamBuf, (unsigned char *)(Temp32+Temp32_len), 512 );
						crc16 = CalCRC16_CCITT(crc16, RamBuf, 512);	
					}
					Uart[Ch].Buf[14]=crc16>>8;
					Uart[Ch].Buf[15]=crc16;
				break;

				//��ת����������
				case 0xFE:
					BootEnable = 0x00;
				break;
				
				//����bootģʽ
				case 0xFF:
					BootEnable = 0x55;
				break;

				default:
				break;
			}			
		break;
		
		default:
		break;
	}
	
	Uart[Ch].Buf[4] |= 0x80;
	TxDataLen = TxDataLen + 6;
	Uart[Ch].Buf[1] = (TxDataLen>>8)&0x00FF;
	Uart[Ch].Buf[2] = TxDataLen&0x00FF;	
	Temp16 = Uart[Ch].Buf[1]*256 + Uart[Ch].Buf[2] + 4;
	crc16 = CalCRC16_CCITT(0x0000,Uart[Ch].Buf, Temp16);	
	Uart[Ch].Buf[Temp16] = crc16>>8;
	Uart[Ch].Buf[Temp16+1] = crc16;
	Uart[Ch].Buf[Temp16+2] = 0x16;	
	//���ʹ���
	Uart[Ch].Flag |= B0000_1000;//��Լ��������׼���������ݱ�־

	//�������ܴ���	
}


void Uartx_Init(UART_Type* UARTx)
{
    LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
    LL_UART_InitTypeDef UART_InitStruct = {0};    
    
	switch((uint32_t)UARTx)
	{
		case UART0_BASE:
			//PA13:UART0-RX   PA14:UART0-TX
			GPIO_InitStruct.Pin = LL_GPIO_PIN_13|LL_GPIO_PIN_14;
			GPIO_InitStruct.Mode = LL_GPIO_MODE_DIGITAL;
			GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
			GPIO_InitStruct.Pull = DISABLE;
			GPIO_InitStruct.RemapPin = DISABLE;
			LL_GPIO_Init(GPIOA, &GPIO_InitStruct);
		
			//PA2:UART0-RX   PA3:UART0-TX
//			GPIO_InitStruct.Pin = LL_GPIO_PIN_2|LL_GPIO_PIN_3;
//			GPIO_InitStruct.Mode = LL_GPIO_MODE_DIGITAL;
//			GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
//			GPIO_InitStruct.Pull = DISABLE;
//			GPIO_InitStruct.RemapPin = DISABLE;
//			LL_GPIO_Init(GPIOA, &GPIO_InitStruct);	
		
			UART_InitStruct.ClockSrc = LL_RCC_UART_OPERATION_CLOCK_SOURCE_APBCLK1;
			/*NVIC�ж�����*/
			NVIC_DisableIRQ(UART0_IRQn);
			NVIC_SetPriority(UART0_IRQn,2);//�ж����ȼ�����
			NVIC_EnableIRQ(UART0_IRQn);
			break;
		
		case UART1_BASE:
			//PB13:UART1-RX   PB14:UART1-TX
			GPIO_InitStruct.Pin = LL_GPIO_PIN_13|LL_GPIO_PIN_14;
			GPIO_InitStruct.Mode = LL_GPIO_MODE_DIGITAL;
			GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
			GPIO_InitStruct.Pull = DISABLE;
			GPIO_InitStruct.RemapPin = DISABLE;			
			LL_GPIO_Init(GPIOB, &GPIO_InitStruct);
		
			//PC2:UART1-RX   PC3:UART1-TX
//			GPIO_InitStruct.Pin = LL_GPIO_PIN_2|LL_GPIO_PIN_3;
//			GPIO_InitStruct.Mode = LL_GPIO_MODE_DIGITAL;
//			GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
//			GPIO_InitStruct.Pull = DISABLE;
//			GPIO_InitStruct.RemapPin = DISABLE;
//			LL_GPIO_Init(GPIOC, &GPIO_InitStruct);	
				
			UART_InitStruct.ClockSrc = LL_RCC_UART_OPERATION_CLOCK_SOURCE_APBCLK1;
			/*NVIC�ж�����*/
			NVIC_DisableIRQ(UART1_IRQn);
			NVIC_SetPriority(UART1_IRQn,2);//�ж����ȼ�����
			NVIC_EnableIRQ(UART1_IRQn);
			break;
			
		case UART4_BASE:
			//PB2:UART4-RX   PB3:UART4-TX
			GPIO_InitStruct.Pin = LL_GPIO_PIN_2|LL_GPIO_PIN_3;
			GPIO_InitStruct.Mode = LL_GPIO_MODE_DIGITAL;
			GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
			GPIO_InitStruct.Pull = DISABLE;
			GPIO_InitStruct.RemapPin = DISABLE;			
			LL_GPIO_Init(GPIOB, &GPIO_InitStruct);
		
			//PA0:UART4-RX   PA1:UART4-TX
//			GPIO_InitStruct.Pin = LL_GPIO_PIN_0|LL_GPIO_PIN_1;
//			GPIO_InitStruct.Mode = LL_GPIO_MODE_DIGITAL;
//			GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
//			GPIO_InitStruct.Pull = DISABLE;
//			GPIO_InitStruct.RemapPin = DISABLE;
//			LL_GPIO_Init(GPIOA, &GPIO_InitStruct);	
			/*NVIC�ж�����*/
			NVIC_DisableIRQ(UART4_IRQn);
			NVIC_SetPriority(UART4_IRQn,2);//�ж����ȼ�����
			NVIC_EnableIRQ(UART4_IRQn);
			break;
		
		case UART5_BASE:
			//PD0:UART5-RX   PD1:UART5-TX
			GPIO_InitStruct.Pin = LL_GPIO_PIN_0|LL_GPIO_PIN_1;
			GPIO_InitStruct.Mode = LL_GPIO_MODE_DIGITAL;
			GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
			GPIO_InitStruct.Pull = DISABLE;
			GPIO_InitStruct.RemapPin = DISABLE;			
			LL_GPIO_Init(GPIOD, &GPIO_InitStruct);
		
			//PC4:UART5-RX   PC5:UART5-TX
//			GPIO_InitStruct.Pin = LL_GPIO_PIN_4|LL_GPIO_PIN_5;
//			GPIO_InitStruct.Mode = LL_GPIO_MODE_DIGITAL;
//			GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
//			GPIO_InitStruct.Pull = DISABLE;
//			GPIO_InitStruct.RemapPin = DISABLE;
//			LL_GPIO_Init(GPIOC, &GPIO_InitStruct);	
			/*NVIC�ж�����*/
			NVIC_DisableIRQ(UART5_IRQn);
			NVIC_SetPriority(UART5_IRQn,2);//�ж����ȼ�����
			NVIC_EnableIRQ(UART5_IRQn);
			break;
				
		default:
			break;
    }
	UART_InitStruct.BaudRate = 115200;								//������
	UART_InitStruct.DataWidth = LL_UART_DATAWIDTH_8B;				//����λ��
	UART_InitStruct.StopBits = LL_UART_STOPBITS_1;					//ֹͣλ
	UART_InitStruct.Parity = LL_UART_PARITY_NONE;					//��żУ��
	UART_InitStruct.TransferDirection = LL_UART_DIRECTION_NONE;	//����-����ʹ��
	UART_InitStruct.InfraredModulation = DISABLE;			        
	LL_UART_Init(UARTx, &UART_InitStruct);
	
	LL_UART_DisableIT_ShiftBuffEmpty(UARTx);  //�رշ����ж�
	LL_UART_EnableIT_ReceiveBuffFull(UARTx);  //�򿪽����ж�
	LL_UART_EnableDirectionTx(UARTx);   	  //�򿪷���ʹ��
	LL_UART_EnableDirectionRx(UARTx);		  //�򿪽���ʹ��
}

