#include "main.h"
#include "user_init.h"
#include "adc.h"

ErrorStatus IWDT_Init(void)
{
	LL_IWDT_InitTypeDef IWDT_InitStruct;
	/* Ĭ�ϲ�ʹ�ô��� */
	IWDT_InitStruct.IwdtWindows    = 0;
	/*����ʱ��*/
	IWDT_InitStruct.OverflowPeriod = LL_IWDT_IWDT_OVERFLOW_PERIOD_8000MS;
	return LL_IWDT_Init(IWDT, &IWDT_InitStruct);
}

void IWDT_Clr(void)
{
  LL_IWDG_ReloadCounter(IWDT);
}

int main(void)
{
    /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
    /* SHOULD BE KEPT!!! */
    MF_Clock_Init();
    
    /* Configure the system clock */
    /* SHOULD BE KEPT!!! */
    MF_SystemClock_Config();
    
    /* Initialize all configured peripherals */
    /* SHOULD BE KEPT!!! */
    MF_Config_Init();
	
    IWDT_Init();//���Ź�
    UserInit();

	
    while(1)
    {  
		IWDT_Clr();             //��ϵͳ���Ź�	
		LED0_TOG();
//		LED1_TOG();
		DelayMs(500);
    }
}


